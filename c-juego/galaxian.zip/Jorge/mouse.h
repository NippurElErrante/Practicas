#ifndef __MOUSE_H
#define __MOUSE_H

#include <dos.h>

typedef enum {FLECHA, MANO, RELOJ, LAPIZ} tipo_cursor;

typedef struct
	{int x;
	 int y;
	 int izq_abajo;
	 int der_abajo;
	 int med_abajo;
	} mouse_data;

typedef enum {BOT_IZQ, BOT_DER, BOT_MED} tipo_boton;

#define MOUSE_MOVES  	  1
#define L_BUTTON_PRESS    2
#define L_BUTTON_RELEASE  4
#define R_BUTTON_PRESS    8
#define R_BUTTON_RELEASE 16
#define M_BUTTON_PRESS   32
#define M_BUTTON_RELEASE 64

int init_mouse(void);

void mostrar_mouse (void);

void ocultar_mouse (void);

void cambiar_cursor (tipo_cursor cursor);

void ubicar_mouse (int x, int y);

void dar_sensitividad (unsigned int x, unsigned int y);

void set_handler (void far interrupt (*handler)(), unsigned int event);

void corregir_area (int left, int top, int right, int bottom);

void leer_mouse (mouse_data *mouse);

int presionar_boton (tipo_boton button, mouse_data *mouse);

int soltar_boton (tipo_boton button, mouse_data *mouse);

void pagina_activa (unsigned int page);

#define MOUSE 0x33         // Interrupci�n de sistema para el mouse
#define TRUE  1
#define FALSE 0

static int mouse_visible;
static union REGS inregs, outregs;
static struct SREGS segregs;

static const int cursor_data[] =
  {// cursor flecha est�ndar
   1, 0,                            // x, y del punto central.
   0x9FFF, 0x8FFF, 0x87FF, 0x83FF,  // Imagen en pantalla (16 palabras).
   0x81FF, 0x80FF, 0x807F, 0x803F,  // Cada palabra marca 16 pixeles (el m�s
   0x801F, 0x800F, 0x80FF, 0x887F,  // bajo es el del extremo derecho). Se
   0x987F, 0xBC3F, 0xFC3F, 0xFE7F,  // aplica un AND a la imagen.

   0x0000, 0x2000, 0x3000, 0x3800,  // Imagen en pantalla (16 palabras)
   0x3C00, 0x3E00, 0x3F00, 0x3F80,  // Despu�s de que se aplica el AND
   0x3FC0, 0x3E00, 0x3600, 0x2300,  // a la imagen se le aplica un XOR
   0x0300, 0x0180, 0x0180, 0x0000,  // con la imagen nueva.

   // cursor mano
   2, 1,
   0xCFFF, 0x87FF, 0x87FF, 0x87FF, 0x813F, 0x8007, 0x8003, 0x8003,
   0x8003, 0x8003, 0x8003, 0x8003, 0x8007, 0xC007, 0xC007, 0xE03F,

   0x0000, 0x3000, 0x3000, 0x3000, 0x3000, 0x36C0, 0x36D8, 0x36D8,
   0x36D8, 0x36D8, 0x3FF8, 0x3FF8, 0x3FF0, 0x1FF0, 0x1FC0, 0x0000,

   // cursor reloj de arena
   7, 7,
   0xC003, 0xC003, 0xC003, 0xC003, 0xE007, 0xF00F, 0xF81F, 0xFC3F,
   0xFC3F, 0xF81F, 0xF00F, 0xE007, 0xC003, 0xC003, 0xC003, 0xC003,

   0x0000, 0x1FF8, 0x0000, 0x1FF8, 0x0D50, 0x06A0, 0x0340, 0x0180,
   0x0180, 0x03C0, 0x07E0, 0x0D50, 0x1AA8, 0x0000, 0x1FF8, 0x0000,

   // cursor l�piz
   0, 15,
   0xFFF1, 0xFFE0, 0xFFC0, 0xFF80, 0xFF01, 0xFE03, 0xFC07, 0xF80F,
   0xF01F, 0xE03F, 0xE07F, 0xC0FF, 0xC1FF, 0x87FF, 0x1FFF, 0x3FFF,

   0x0000, 0x000E, 0x001C, 0x003A, 0x0074, 0x00E8, 0x01D0, 0x03A0,
   0x0740, 0x0E80, 0x0D00, 0x1A00, 0x1800, 0x2000, 0x4000, 0x0000

   // Para usar m�s cursores, definirlos aqu� y agregar su nombre a la
   // enumeraci�n tipo_cursor en MOUSE.H.
};

void cambiar_cursor (tipo_cursor cursor)
  {inregs.x.ax = 9;
   inregs.x.bx = *(cursor_data + 34 * cursor);
   inregs.x.cx = *(cursor_data + 34 * cursor + 1);
   inregs.x.dx = FP_OFF (cursor_data + 34 * cursor + 2);
   segregs.es = FP_SEG (cursor_data + 34 * cursor + 2);
   int86x (MOUSE, &inregs, &outregs, &segregs);
  }

int init_mouse (void)
  {int cant_botones;
   inregs.x.ax = 0;
   int86 (MOUSE, &inregs, &outregs);
   if (outregs.x.bx == 2 || inregs.x.bx == 0xFFFF)
     {cant_botones = 2;
     }
    else if (outregs.x.bx == 3)
     {cant_botones = 3;
     }
    else
     {cant_botones = -1;
     }
   if (!outregs.x.ax)
     {cant_botones = 0;
     }
   mouse_visible = FALSE;
   cambiar_cursor (FLECHA);
   mostrar_mouse ();
   dar_sensitividad (8, 8);
   return cant_botones;
  }

void mostrar_mouse (void)
  {inregs.x.ax = 1;
   int86 (MOUSE, &inregs, &outregs);
   mouse_visible = TRUE;
  }

void ocultar_mouse (void)
  {if (mouse_visible)
     {inregs.x.ax = 2;
      int86(MOUSE, &inregs, &outregs);
      mouse_visible = FALSE;
     }
  }

void ubicar_mouse (int x, int y)
  {inregs.x.ax = 4;
   inregs.x.cx = x;
   inregs.x.dx = y;
   int86 (MOUSE, &inregs, &outregs);
  }

void dar_sensitividad (unsigned int x, unsigned int y)
  {inregs.x.ax = 0xF;
   inregs.x.cx = x;
   inregs.x.dx = y;
   int86(MOUSE, &inregs, &outregs);
  }

void set_handler (void far interrupt (*handler)(), unsigned int event)
  {inregs.x.ax = 0xC;
   inregs.x.cx = event;
   inregs.x.dx = FP_SEG(handler);
   segregs.es = FP_OFF(handler);
   int86x(MOUSE, &inregs, &outregs, &segregs);
  }

void corregir_area (int left, int top, int right, int bottom)
  {inregs.x.ax = 0x10;
   inregs.x.cx = left;
   inregs.x.dx = top;
   inregs.x.si = right;
   inregs.x.di = bottom;
   int86 (MOUSE, &inregs, &outregs);
  }

void pagina_activa (unsigned int page)
  {inregs.x.ax = 0x1D;
   inregs.x.bx = page;
   int86(MOUSE, &inregs, &outregs);
  }

void leer_mouse (mouse_data *mouse)
  {inregs.x.ax = 3;
   int86 (MOUSE, &inregs, &outregs);
   mouse->x = outregs.x.cx;
   mouse->y = outregs.x.dx;
   mouse->izq_abajo = outregs.x.bx & 1;
   mouse->der_abajo = (outregs.x.bx & 2) >> 1;
   mouse->med_abajo = (outregs.x.bx & 4) >> 2;
  }

int presionar_boton (tipo_boton button, mouse_data *mouse)
  {inregs.x.ax = 5;
   inregs.x.bx = button;
   int86(MOUSE, &inregs, &outregs);
   mouse->izq_abajo = outregs.x.ax & 1;
   mouse->der_abajo = (outregs.x.ax & 2) >> 1;
   mouse->med_abajo = (outregs.x.ax & 4) >> 2;
   mouse->x = outregs.x.cx;
   mouse->y = outregs.x.dx;
   return outregs.x.bx;
  }

int soltar_boton (tipo_boton button, mouse_data *mouse)
  {inregs.x.ax = 6;
   inregs.x.bx = button;
   int86(MOUSE, &inregs, &outregs);
   mouse->izq_abajo = outregs.x.ax & 1;
   mouse->der_abajo = (outregs.x.ax & 2) >> 1;
   mouse->med_abajo = (outregs.x.ax & 4) >> 2;
   mouse->x = outregs.x.cx;
   mouse->y = outregs.x.dx;
   return outregs.x.bx;
  }

#endif