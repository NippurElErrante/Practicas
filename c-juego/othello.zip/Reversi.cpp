//JUEGO REVERSI (Programa fuente)
//Proyecto #1
//Curso ORGANIZACION DE DATOS
//Prof. SANTIAGO CAAMA�O

//Programadores:
//Adri�n S�nchez  962706-1
//Adriana Chaves  971329-3
//Leonardo Le�n   972862-0
//JULIO 17, 2000

#include<stdio.h>
#include<ctype.h>
#include<stdlib.h>
#include<string.h>
#include<conio.h>
#include<dos.h>

#define enter  13
#define escape 27
#define Derecha 77
#define Izquierda 75
#define Arriba 72
#define Abajo 80

struct nodos{
	int contenido;
	int numero;
	struct nodos * arriba;
	struct nodos * abajo;
	struct nodos * izquierda;
	struct nodos * derecha;
	struct nodos * arribad;
	struct nodos * arribai;
	struct nodos * abajod;
	struct nodos * abajoi;
};

typedef struct nodos lista;
lista *inicio=NULL, *nuevo, *ultimo, *ini, *temp;
char jugador1[18],jugador2[18];
int puntos1=0, puntos2=0;

void jugadores();
void refrescar();
void jugadas(int j);
void sonido1();
void cursor();
void presentacion();
void despedida();
void finaljuego();
void inicializa();
void enlazar();
void free();
void cuadriculado();


void main()
{
	inicializa();
	enlazar();
	clrscr();
	presentacion();
	clrscr();
	jugadores();
	clrscr();
	cuadriculado();
	cursor();
	getchar();
}

void inicializa(){
int i,j,cont=1;
	for(i=0; i< 8; i++){
		nuevo= new lista;
		nuevo->numero=cont;
		nuevo->contenido=0;
		cont+=1;
		if (!inicio){
		inicio = nuevo;
		ultimo = inicio;
		}
		else
		{ nuevo->izquierda = ultimo;
		ultimo->derecha = nuevo;
		ultimo= nuevo;
		}
	}//fin for de lista inicial
ini=inicio;
	for(i=0;i<7;i++)
		{
		temp=ini;
		for(j=0;j<8;j++)
		{
		nuevo=new lista;
		nuevo->numero=cont;
		nuevo->contenido=0;
		cont+=1;
		nuevo->arriba=temp;
		temp->abajo=nuevo;
		if(temp->izquierda){
			temp->izquierda->abajod=nuevo;
			nuevo->arribai=temp->izquierda;
			nuevo->izquierda=temp->izquierda->abajo;
			temp->izquierda->abajo->derecha=nuevo;
		}
		if(temp->derecha){
			temp->derecha->abajoi=nuevo;
			nuevo->arribad=temp->derecha;
		}
	temp=temp->derecha;
	}//for j<8
	ini=ini->abajo;
	}//for i<7*/
//Pone las primeras cuatro jugadas
temp=inicio;

	for(i=0;i<3;i++)
	       temp=temp->derecha;
	for(i=0;i<3;i++)
		temp=temp->abajo;

temp->contenido=1;
temp->derecha->contenido=2;
temp->abajo->contenido=2;
temp->abajo->derecha->contenido=1;

}//fin iniciliza punteros


void enlazar()
{
int cont;
	ini=inicio;
	temp=ultimo;
	for(cont=0;cont<8;cont++){//enlaza verticalmente
		temp->derecha=ini;
		ini->izquierda=temp;
		if(cont!=7){
			ini=ini->abajo;
			temp=temp->abajo;
		}//if cont!=7
	}//for
	temp=inicio;
	for(cont=0;cont<8;cont++)//enlaza horizontalmente
	{
		temp->arriba=ini;
		ini->abajo=temp;
		if(cont!=7){
		ini=ini->derecha;
		temp=temp->derecha;
		}//if cont!=7
	} //for
}//fin enlaza circular


void cursor(){
temp=inicio;
char e;
int x=25,y=5,j=1,o,l=27;

	for(;;)
	{
		refrescar();
		if(puntos1+puntos2==64)
			finaljuego();
		if(j==1){
			textcolor(LIGHTBLUE);
			gotoxy(2,23);
			cprintf("JUEGA");
			gotoxy(2,24);
			cprintf("%s",jugador1);
			gotoxy(2,25);
			cprintf("Puntos: %d  ",puntos1);
			textcolor(BLACK);//para limpiar el otro mensaje
			gotoxy(61,23);
			cprintf("JUEGA");
			gotoxy(61,24);
			cprintf("%s",jugador2);
			gotoxy(61,25);
			cprintf("Puntos: %d  ",puntos2);
		  }
		  else{

			textcolor(BROWN);
			gotoxy(61,23);
			cprintf("JUEGA");
			gotoxy(61,24);
			cprintf("%s",jugador2);
			gotoxy(61,25);
			cprintf("Puntos: %d  ",puntos2);
			textcolor(BLACK);//para limpiar el otro mensaje
			gotoxy(2,23);
			cprintf("JUEGA");
			gotoxy(2,24);
			cprintf("%s",jugador1);
			gotoxy(2,25);
			cprintf("Puntos: %d  ",puntos1);
			}

	       textcolor(LIGHTCYAN+BLINK);
	       gotoxy(x,y);
	       cprintf("+");

	       o=0;
	       l=27;
	while(!kbhit())//hasta que se presione una tecla
		{
		if(l>51)
			 l=27;
		if(o>26)
			 o=0;
		textcolor(WHITE);
		//
		gotoxy(l,2);
		textcolor(YELLOW);
		gotoxy(21,2);
		cprintf("* * * J U E G O   R E V E R S I * * *");

		l+=1;
		o+=1;
		delay(6);
		}
	e=getch();
	gotoxy(x,y);
	cprintf(" ");
	switch(e)
	{
		case Derecha: sonido1();
			temp=temp->derecha;
			x+=4;
			if(x>55)
				x=25;
			break;
		case Abajo:  sonido1();
			temp=temp->abajo;
			y+=2;
			if(y>20) y=5;
			break;

		case Arriba:    sonido1();
			temp=temp->arriba;
			y-=2;
			if(y<5)
				y=19;
			break;

		case Izquierda:  sonido1();
			temp=temp->izquierda;
			x-=4;
			if(x<23)
				x=53;
			break;

		case enter:
		   if(temp->contenido==0)
			{
			sonido1();
			textcolor(WHITE);
			gotoxy(x,y);
			temp->contenido=j;
			jugadas(j);
			x=25;y=5;
			temp=inicio;
			if(j==1)
				j=2;
			else
				j=1;
	}
	else
	{
		gotoxy(28,23);
		printf("Posicion Ocupada\a");
		delay(250);
		gotoxy(28,23);
		printf("                      ");
	}
	break;//fin

		case escape: finaljuego();//salida();
		break;

		default:  break;

	}//fin switch
    }//for infinito
}//fin funcion-moviendo

void cuadriculado(){

     textcolor(2);
     gotoxy(23,4);
     cprintf("�������������������������������Ŀ");
     gotoxy(23,5);
     cprintf("�   �   �   �   �   �   �   �   � ");
     gotoxy(23,6);
     cprintf("�������������������������������Ĵ");
     gotoxy(23,7);
     cprintf("�   �   �   �   �   �   �   �   � ");
     gotoxy(23,8);
     cprintf("�������������������������������Ĵ");
     gotoxy(23,9);
     cprintf("�   �   �   �   �   �   �   �   � ");
     gotoxy(23,10);
     cprintf("�������������������������������Ĵ");
     gotoxy(23,11);
     cprintf("�   �   �   �   �   �   �   �   � ");
     gotoxy(23,12);
     cprintf("�������������������������������Ĵ");
     gotoxy(23,13);
     cprintf("�   �   �   �   �   �   �   �   � ");
     gotoxy(23,14);
     cprintf("�������������������������������Ĵ");
     gotoxy(23,15);
     cprintf("�   �   �   �   �   �   �   �   � ");
     gotoxy(23,16);
     cprintf("�������������������������������Ĵ");
     gotoxy(23,17);
     cprintf("�   �   �   �   �   �   �   �   � ");
     gotoxy(23,18);
     cprintf("�������������������������������Ĵ");
     gotoxy(23,19);
     cprintf("�   �   �   �   �   �   �   �   � ");
     gotoxy(23,20);
     cprintf("���������������������������������");
}


void presentacion()
{
int x=27,l;

textbackground(BLACK);
clrscr();
textcolor(YELLOW);
gotoxy(22,10);
cprintf("* * * J U E G O   R E V E R S I * * *");

while(!kbhit())//hasta que se presione una tecla
	{
	if(x>51)
	x=27;
	x+=1;
	}
	getch();//para en el proximo proceso de lectura no se carga la tecla que se pulse..
	}


void sonido1()
{
long int i;
	for(i=400;i<4500;i++)
	{
		sound(i);
		sound(i*i);
	}
	nosound();
}


void jugadas(int j)
{
lista *temp2;
int ok=0,encontro=0;

//JUGADAS HACIA LA DERECHA
temp2=temp;
if((temp->numero%8)!=0)
	{
	while(!ok)
		{
		temp2=temp2->derecha;
		if(temp2->contenido==j||temp2->contenido==0||(temp2->numero%8)==0)
			{
			ok=1;
			if(temp2->contenido==j)
			encontro=1;
			}
		}//while
	}

if(encontro)
	{
	temp2=temp2->izquierda;
	while(temp2->contenido!=j)
	{
	if(j==2)
		temp2->contenido=2;
	else
		temp2->contenido=1;
	temp2=temp2->izquierda;
	}//for
}//if


//JUGADAS HACIA LA IZQUIERDA
ok=encontro=0;
temp2=temp;

if(((temp->numero-1)%8)!=0)
	{
	while(!ok)
		{
		temp2=temp2->izquierda;
		if(temp2->contenido==j||temp2->contenido==0||((temp2->numero-1)%8)==0)
			{
			ok=1;
			if(temp2->contenido==j)
				encontro=1;
			}
	}//while
}

if(encontro)
	{
	temp2=temp2->derecha;
	while(temp2->contenido!=j)
		{
		if(j==2)
			temp2->contenido=2;
		else
			temp2->contenido=1;
		temp2=temp2->derecha;
	}//while
}//if

//JUGADAS HACIA ARRIBA
ok=encontro=0;
temp2=temp;
if((temp->numero)>8)
	{
	while(!ok)
		{
		temp2=temp2->arriba;
		if(temp2->contenido==j||temp2->contenido==0||((temp2->numero)>=1&&(temp2->numero)<=8))
			ok=1;
		if(temp2->contenido==j)
			encontro=1;
		}//while
}

if(encontro)//calculo
	{
	temp2=temp2->abajo;
	while(temp2->contenido!=j)
	{
		if(j==2)
			temp2->contenido=2;
		else
			temp2->contenido=1;
		temp2=temp2->abajo;
	}//while
}//if



//JUGADAS HACIA ABAJO
ok=encontro=0;
temp2=temp;
if((temp->numero)<57)
	{
	while(!ok)
		{
		temp2=temp2->abajo;
	if(temp2->contenido==j||temp2->contenido==0||((temp2->numero)>=57&&(temp2->numero)<=64))
		ok=1;
	if(temp2->contenido==j)
		encontro=1;
	}//while
}

if(encontro)//calculo
	{
	temp2=temp2->arriba;
	while(temp2->contenido!=j)
		{
		if(j==2)
			temp2->contenido=2;
		else
			temp2->contenido=1;
		temp2=temp2->arriba;
	}//while
}//if


//JUGADAS HACIA ARRIBA-DERECHA
ok=encontro=0;
temp2=temp;
if((temp->numero)>8&&((temp->numero)%8)!=0)
	{
	while(!ok)
		{
		temp2=temp2->arribad;
		if(temp2->contenido==j||temp2->contenido==0||temp2->arribad==NULL)
			ok=1;
		if(temp2->contenido==j)
			encontro=1;
		}//while
}//if

if(encontro)//calculo
	{
	temp2=temp2->abajoi;
	while(temp2->contenido!=j)
		{
		if(j==2)
			temp2->contenido=2;
		else
			temp2->contenido=1;
		temp2=temp2->abajoi;
	}//while
}//if


//JUGADAS HACIA ABAJO-IZQUIERDA
ok=encontro=0;
temp2=temp;
if((temp->numero)<57&&(temp->numero-1)%8!=0)
	{
	while(!ok)
		{
		temp2=temp2->abajoi;
	if(temp2->contenido==j||temp2->contenido==0||temp2->abajoi==NULL)
		ok=1;
	if(temp2->contenido==j)
		encontro=1;
	}//while
}//if

if(encontro)//calculo
	{
	temp2=temp2->arribad;
	while(temp2->contenido!=j)
		{
		if(j==2)
			temp2->contenido=2;
		else
			temp2->contenido=1;
		temp2=temp2->arribad;
	}//while
}//if

//JUGADA HACIA ARRIBA-IZQUIERDA
ok=encontro=0;
temp2=temp;
if((temp->numero)>8&&((temp->numero)-1)%8!=0)
	{
	while(!ok)
		{
		temp2=temp2->arribai;
		if(temp2->contenido==j||temp2->contenido==0||temp2->arribai==NULL)
			ok=1;
		if(temp2->contenido==j)
			encontro=1;
	}//while
}//if

if(encontro)//calculo
	{
	temp2=temp2->abajod;
	while(temp2->contenido!=j)
		{
		if(j==2)
			temp2->contenido=2;
		else
			temp2->contenido=1;
		temp2=temp2->abajod;
	}//while
}//if


//JUGADA HACIA ABAJO-DERECHA
ok=encontro=0;
temp2=temp;
if((temp->numero)<57&&(temp->numero%8)!=0)
	{
	while(!ok)
		{
		temp2=temp2->abajod;
		if(temp2->contenido==j||temp2->contenido==0||temp2->abajod==NULL)
			ok=1;
		if(temp2->contenido==j)
			encontro=1;
	}//while
}//if

if(encontro)//calculo
	{
	temp2=temp2->arribai;
	while(temp2->contenido!=j)
		{
		if(j==2)
			temp2->contenido=2;
		else
			temp2->contenido=1;
		temp2=temp2->arribai;
	}//while
}//if

}



void refrescar()
{
int x=25,y=5,i,j;
lista *primer,*act;
puntos1=0;
puntos2=0;
primer=inicio;
	for(i=0;i<8;i++){
		act=primer;
		for(j=0;j<8;j++)
		{
		if(act->contenido!=0){
			gotoxy(x,y);
			if(act->contenido==1)
			{
				textcolor(LIGHTBLUE);
				cprintf("O");
				puntos1+=1;
			} //if
		else{
			textcolor(BROWN);
			cprintf("X");
			puntos2+=1;}   //else
		     }//if !0
		act=act->derecha;
		x+=4; if(x>53) x=25;
		}//for j
		primer=primer->abajo;
		y+=2; if(y>19) y=5;
	}//for i
}

// FUNCION PARA CAPTURAR POR PANTALLA EL NOMBRE DE LOS JUGADORES
void jugadores()
{
int x1,y1,x2,y2,i,i2,i3,tam1=3,tam2=3,cont;
for(i=1;i<=2;i++){
repite:
clrscr();
textcolor(YELLOW);
gotoxy(25,15);
cprintf("Jugador %d: ",i);
if(i==1)
  {
  gets(jugador1);
  tam1=strlen(jugador1);
  }
else
  {
  gets(jugador2);
  tam2=strlen(jugador2);
  }
if(tam1==0||tam2==0||tam1>18||tam2>18||jugador1[0]==' '||jugador2[0]==' ')
goto repite;
}//for i<=2
}//FIN DE LA FUNCION JUGADORES

//FUNCION QUE DESPLIEGA MENSAJE DE DESPEDIDA
void despedida()
{
	gotoxy(18,10);
	textcolor(WHITE+BLINK);
	cprintf("! ! GRACIAS POR JUGAR REVERSI ! ! ");
	delay(50);
	delay(2000);
	free();
	textbackground(BLACK);clrscr();exit(0);
}//FIN DE LA FUNCION DESPEDIDA


void finaljuego()
{

clrscr();

	if(puntos1==puntos2)
		{
		gotoxy(22,13);
		printf("�FELICIDADES HAN EMPATADO!");
		gotoxy(2,15);
		printf("Jugador %s: %d puntos.",jugador1,puntos1);
		gotoxy(50,15);
		printf("Jugador %s: %d puntos.",jugador2,puntos2);
		}
	else
		{
		if(puntos1>puntos2)
			{
			gotoxy(22,13);
			printf("�FELICIDADES %s HAS GANADO!",jugador1);
			gotoxy(2,15);
			printf("Jugador %s: %d puntos.",jugador1,puntos1);
			gotoxy(50,15);
			printf("Jugador %s: %d puntos.",jugador2,puntos2);}
	else
		{
		gotoxy(22,13);
		printf("�FELICIDADES %s HAS GANADO!",jugador2);
		gotoxy(2,15);
		printf("Jugador %s: %d puntos.",jugador1,puntos1);
		gotoxy(50,15);
		printf("Jugador %s: %d puntos.",jugador2,puntos2);}
	}
getche();
despedida();
}


void free()
{
int i,j;
ini=inicio;
temp=ultimo;
	for(i=0;i<7;i++)
	{
		temp=temp->abajo;
		ini=inicio->abajo;
	}

}//fin free
